#pragma once

#include <QFont>
#include <QString>
#include <QtSql/QtSql>
#include <unordered_map>

static std::unordered_map<QString, QString> CameraRoomMap{
    {QStringLiteral("http://admin:0gfhjkm@192.168.6.62/video2.mjpg"), QStringLiteral("Аудитория 408")},
    {QStringLiteral("http://admin:0gfhjkm@192.168.6.61/video2.mjpg"), QStringLiteral("Аудитория 401")}};

inline bool initDatabaseConnection() {
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE", "AttendanceConnection");
    db.setDatabaseName("C:\\cicada-main\\sibsutis\\graduate\\AttendanceVision\\data\\attendance.db");

    if (!db.open()) {
        qDebug() << "Unable to open DB\n";
        return false;
    }

    return true;
}
