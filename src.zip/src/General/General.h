#pragma once

#include <string>
#include <unordered_set>

const std::unordered_set<std::string> CamerasUrls{"http://admin:0gfhjkm@192.168.6.62/video2.mjpg",
                                                  "http://admin:0gfhjkm@192.168.6.61/video2.mjpg"};
