#include "CameraManager.h"

#include "../General/General.h"

CameraManager::CameraManager() {}

CameraManager::~CameraManager() {
    for (auto& [url, cap] : streams) {
        if (cap) {
            cap->release();
            delete cap;
        }
    }
}

bool CameraManager::addCamera(const QString& url, const QString& room) {
    // Добавляем в базу
    QSqlQuery query;
    query.prepare("INSERT INTO cameras (url, room) VALUES (:url, :room)");
    query.bindValue(":url", url);
    query.bindValue(":room", room);
    if (!query.exec()) return false;

    // Добавляем в память
    std::string stdUrl = url.toStdString();
    cameraUrls.insert(stdUrl);
    return true;
}

bool CameraManager::removeCamera(const QString& url) {
    // Удаляем из базы
    QSqlQuery query;
    query.prepare("DELETE FROM cameras WHERE url = :url");
    query.bindValue(":url", url);
    if (!query.exec()) return false;

    // Удаляем из памяти
    std::string stdUrl = url.toStdString();
    cameraUrls.erase(stdUrl);

    auto it = streams.find(stdUrl);
    if (it != streams.end()) {
        it->second->release();
        delete it->second;
        streams.erase(it);
    }

    return true;
}

const std::unordered_set<std::string>& CameraManager::getCameraUrls() const { return cameraUrls; }

QMap<QString, QString> CameraManager::getCameras() const {
    QMap<QString, QString> cameraMap;

    QSqlDatabase db = QSqlDatabase::database("AttendanceConnection");
    if (!db.isOpen()) {
        qDebug() << "Ошибка: база данных не открыта в getCameras";
        return cameraMap;
    }

    QSqlQuery query(db);
    query.prepare("SELECT url, room FROM cameras");

    if (!query.exec()) {
        qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
        return cameraMap;
    }

    while (query.next()) {
        QString url = query.value(0).toString();
        QString room = query.value(1).toString();
        cameraMap.insert(url, room);
    }

    return cameraMap;
}

bool CameraManager::openStream(const std::string& url) {
    if (streams.find(url) == streams.end()) {
        auto* cap = new cv::VideoCapture(url);
        if (!cap->isOpened()) {
            delete cap;
            return false;
        }
        streams[url] = cap;
    }
    return true;
}

cv::VideoCapture* CameraManager::getCapture(const std::string& url) {
    if (streams.find(url) != streams.end()) {
        return streams[url];
    }
    return nullptr;
}
