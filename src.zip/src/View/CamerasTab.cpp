#include "CamerasTab.h"
#include <QGridLayout>
#include "../General/General.h"

CamerasTab::CamerasTab(CameraController* controller, QWidget* parent) : QWidget(parent), controller(controller) {
    setupUI();
}

void CamerasTab::setupUI() {
    auto layout = new QGridLayout(this);
    fillCamerasLayout(layout);
    setLayout(layout);
}

void CamerasTab::fillCamerasLayout(QGridLayout* layout) {
    int row = 0, col = 0;
    for (const auto& url : CameraRoomMap) {
        QString cameraUrl = url.first;
        QString roomNumber = url.second;

        // Создаём кнопку с номером аудитории
        auto* btn = new QPushButton(roomNumber, this);
        btn->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        btn->setFont(QFont("", 24, QFont::Bold));  // крупный шрифт
        layout->addWidget(btn, row, col);

        // По клику — открываем диалог с живым стримом
        connect(btn, &QPushButton::clicked, this,
                [=, this]() { controller->handleCameraClicked(url.second.toStdString()); });

        // Две кнопки в строке
        if (++col >= 2) {
            col = 0;
            ++row;
        }
    }
}
