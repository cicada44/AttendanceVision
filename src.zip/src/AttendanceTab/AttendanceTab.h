#pragma once

#include <QWidget>

class AttendanceTab : public QWidget {
    Q_OBJECT

public:
    explicit AttendanceTab(QWidget* parent = nullptr);
};