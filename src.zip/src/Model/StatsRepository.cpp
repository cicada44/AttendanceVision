// src/Model/StatsRepository.cpp
#include "StatsRepository.h"
#include <QtSql>

StatsRepository::StatsRepository(const QString& dbPath) : m_dbPath(dbPath) {}

static QSqlDatabase openDb(const QString& path) {
    auto db = QSqlDatabase::database("AttendanceConnection");
    db.setDatabaseName(path);
    if (!db.open()) {
        qWarning() << "Cannot open DB" << path << db.lastError();
    }
    return db;
}

QVector<QPair<QDateTime, int>> StatsRepository::getEntries(const QDateTime& from, const QDateTime& to) {
    auto db = openDb(m_dbPath);
    QSqlQuery q(db);
    q.prepare(R"(SELECT timestamp, COUNT(*) 
                 FROM Visits 
                 WHERE direction='in' AND timestamp BETWEEN :from AND :to
                 GROUP BY timestamp)");
    q.bindValue(":from", from);
    q.bindValue(":to", to);
    QVector<QPair<QDateTime, int>> res;
    if (q.exec()) {
        while (q.next()) {
            res.emplace_back(q.value(0).toDateTime(), q.value(1).toInt());
        }
    }
    return res;
}

QVector<QPair<QDateTime, int>> StatsRepository::getExits(const QDateTime& from, const QDateTime& to) {
    auto db = openDb(m_dbPath);
    QSqlQuery q(db);
    q.prepare(R"(SELECT timestamp, COUNT(*)
                 FROM Visits
                 WHERE direction = 'out'
                   AND timestamp BETWEEN :from AND :to
                 GROUP BY timestamp)");
    q.bindValue(":from", from);
    q.bindValue(":to", to);

    QVector<QPair<QDateTime, int>> res;
    if (q.exec()) {
        while (q.next()) {
            res.emplace_back(q.value(0).toDateTime(), q.value(1).toInt());
        }
    } else {
        qWarning() << "StatsRepository::getExits failed:" << q.lastError().text();
    }
    return res;
}
